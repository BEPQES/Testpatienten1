// Initialize Firebase
var config = {
  apiKey: "AIzaSyD-sNazm7gldRRMHzPvBrFs4wFnNDtx7uY",
  authDomain: "test-be-ea76b.firebaseapp.com",
  databaseURL: "https://test-be-ea76b-default-rtdb.firebaseio.com",
  projectId: "test-be-ea76b",
  storageBucket: "test-be-ea76b.appspot.com",
  messagingSenderId: "1028673492327",
  appId: "1:1028673492327:web:618b72eaf3ae5a2dc10bc2",
  measurementId: "G-3T42M8VHW4"
};
firebase.initializeApp(config);
var rootRef = firebase.database().ref();

